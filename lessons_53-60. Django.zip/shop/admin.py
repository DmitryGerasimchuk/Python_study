from django.contrib import admin
from .models import Course, Category

admin.site.site_header = "Arhwolf courses: admin"
admin.site.site_title = "Arhwolf courses"
admin.site.index_title = "Welcome to the Arhwolf courses admin area"


# фиксируем, что и как отображается на главной панели администратора
class CourseAdmin(admin.ModelAdmin):
    list_display = ("title", "students_qty", "price", "category")


class CoursesInLine(admin.TabularInline):
    model = Course
    exclude = ["created_at"]
    extra = 1


class CategoryAdmin(admin.ModelAdmin):
    list_display = ("title", "created_at")
    fieldsets = [
        (None, {"fields": ["title"]}),
        ("Dates", {"fields": ["created_at"], "classes": ["collapse"]}),
    ]
    inlines = [CoursesInLine]


# Создаем админ-панель для наших категорий
admin.site.register(Category, CategoryAdmin)
admin.site.register(Course, CourseAdmin)
