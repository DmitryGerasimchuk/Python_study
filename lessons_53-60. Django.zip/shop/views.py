from django.shortcuts import render, get_object_or_404
from django.http import HttpResponse, Http404  # испортировали класс для запросов
from .models import Course  # испортируем из текущей папки модуль Course

# Create your views here.


def index(request):  # функция для обращения на главную страницу магазина
    courses = Course.objects.all()
    # return HttpResponse("Hello from the shop app!") # когда не было курсов отображалась эта строка
    # return HttpResponse("".join([str(course) + "<br>" for course in courses]))
    # return HttpResponse(courses)
    return render(request, "shop/courses.html", {"courses": courses})


def single_course(
    request, course_id
):  # функция для отображения информации об одном курсе
    # # Чтобы отображалась ошидка 404, если курса нет, сделаем два варианта:
    # # Первый вариант - конструкция try-except:
    # try:
    #     course = Course.objects.get(pk=course_id)
    #     return render(request, "shop/single_course.html", {"course": course})
    # except Course.DoesNotExist:
    #     raise Http404()
    # Второй вариант - использование функции get_object_or_404:
    course = get_object_or_404(Course, pk=course_id)
    return render(request, "shop/single_course.html", {"course": course})
