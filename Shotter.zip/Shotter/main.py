import pygame  # импорт игрового модуля
import sys  # импорт системного модуля
from random import randint  # импорт рандомного выражения для рандомного появления инопланетянина

pygame.init()  # инициация игрового модуля

game_font = pygame.font.Font(None, 36)  # "инициация" шрифта для записи информации по игре

'''Создание экрана игры'''
screen_width, screen_height = 800, 600  # определение границ экрана - ширина и высота
screen_fill_color = (32, 52, 71)  # определение цвета игрового экрана - темно-синий цвет
screen = pygame.display.set_mode((screen_width, screen_height))  # создание экрана
pygame.display.set_caption("Awesome Shooter Game by Arhwolf")  # создание назписи/заголовка игры

'''Создание объекта космического коробля'''
FIGHTER_STEP = 1  # шаг движения объекта на экране
fighter_image = pygame.image.load('images/fighter.png')  # загрузка элемента (картинки) для игры - космический корабль
fighter_width, fighter_height = fighter_image.get_size()  # передача двум переменным размеров коробля (ширина и высота)
fighter_x, fighter_y = screen_width / 2 - fighter_width / 2, screen_height - fighter_height  # определение начальной координаты коробля (центр экрана внизу)
fighter_is_moving_left, fighter_is_moving_right = False, False  # флаги принятия решений для коробля

'''Создание объекта ракеты (оружия)'''
ROCKET_STEP = 1.5  # шаг движения запущенной ракеты на экране
rocket_image = pygame.image.load('images/rocket.png')  # загрузка элемента (картинки) для игры - ракета
rocket_width, rocket_height = rocket_image.get_size()  # передача двум переменным размера ракеты (ширина и высота)
rocket_x, rocket_y = fighter_x + fighter_width / 2 - rocket_width / 2, fighter_y - rocket_height  # определение начальной координаты выпущенной ракеты, если корабль не двигался (можно упростить строку, присвоив переменным значения 0)
rocket_was_fired = False  # флаг принятия решения для ракеты

'''Создание инопланетного врага'''
AlIEN_STEP = 0.1  # шаг движения инопланетянина
alien_speed = AlIEN_STEP # скорость движения инопланетянина по экрану
alien_image = pygame.image.load('images/alien.png')  # загрузка элемента (картинки) для игры - инопланетянин (враг)
alien_width, alien_height = alien_image.get_size()  # передача двум переменным размера инопланетянина (ширина и высота)
alien_x, alien_y = randint(0,
                           screen_width - alien_width), 0  # определение начальной координаты появления инопланетянина

game_is_running = True  # флаг для входа в цикл

game_score = 0 # счетчик попаданий ракеты в инопланетянина

while game_is_running:
    for event in pygame.event.get():  # регистрация всех событий
        if event.type == pygame.QUIT:  # если начали на крестик на экране - выход из игры
            sys.exit()
        if event.type == pygame.KEYDOWN:  # подключение клавиш (нажатие)
            if event.key == pygame.K_LEFT:  # при нажатии клавиши влево идет перемещение коробля на шаг влево
                fighter_is_moving_left = True  # изменение флага: начало события
            if event.key == pygame.K_RIGHT:  # при нажатии клавиши вправо идет перемещение коробля на шаг вправо
                fighter_is_moving_right = True  # изменение флага: начало события
            if event.key == pygame.K_SPACE:  # изменение флага при нажатии проблела
                rocket_was_fired = True
                rocket_x = fighter_x + fighter_width / 2 - rocket_width / 2  # определение начальной координаты выпущенной ракеты, если корабль не двигался
                rocket_y = fighter_y - rocket_height  # определение начальной координаты выпущенной ракеты, если корабль не двигался
        if event.type == pygame.KEYUP:  # создание плавного движения для коробля при нажатии клавиши
            if event.key == pygame.K_LEFT:
                fighter_is_moving_left = False  # изменение флага: окончание события
            if event.key == pygame.K_RIGHT:
                fighter_is_moving_right = False  # изменение флага: окончание события

    if fighter_is_moving_left and fighter_x >= FIGHTER_STEP:  # при нажатии клавиши и измении флага происходит движение коробля влево
        fighter_x -= FIGHTER_STEP

    if fighter_is_moving_right and fighter_x <= screen_width - fighter_width - FIGHTER_STEP:  # при нажатии клавиши и измении флага происходит движение коробля вправо
        fighter_x += FIGHTER_STEP

    # alien_y += AlIEN_STEP  # перемещение инопланетянина по экрану с постоянной скоростью (без учкорения)
    alien_y += alien_speed # перемещение инопланетянина по экрану с опредленной скоростью

    if rocket_was_fired and rocket_y + rocket_height < 0:  # при нажатии (удержании) клавиши "Пробел" и достижении границы экрана, изменение флага у ракеты (ракета исчезает)
        rocket_was_fired = False

    if rocket_was_fired:  # при нажатии (удержании) клавиши "Пробел", измнение положения ракеты вдоль оси Y на шаг
        rocket_y -= ROCKET_STEP

    screen.fill(screen_fill_color)  # передача цвета экрана

    screen.blit(fighter_image, (fighter_x, fighter_y))  # передача на экран коробля

    screen.blit(alien_image, (alien_x, alien_y))  # передача на экран инопланетянина

    if rocket_was_fired:  # передача на экран ракеты
        screen.blit(rocket_image, (rocket_x, rocket_y))

    game_score_text = game_font.render(f"Счёт: {game_score}", True, 'green') # создание надртси для отображения счета игры
    screen.blit(game_score_text, (20, 20)) # отображения надписи счета на экране

    pygame.display.update()  # обновление всех изменений, чтобы игра запустилась

    if alien_y + alien_height > fighter_y:  # условие для изменения флага - выход из цикла игры
        game_is_running = False

    if rocket_was_fired and alien_x < rocket_x < alien_x + alien_width - rocket_width and alien_y < rocket_y < alien_y + alien_height - rocket_height:  # условие, когда пакета попадает в центр инопланетянина
        rocket_was_fired = False  # изменение флага ракеты (ракета исчезает)
        alien_x, alien_y = randint(0,
                                   screen_width - alien_width), 0  # инопланетянин исчезает и появляется в новом месте
        alien_speed += AlIEN_STEP/2 # увеличение скорости нового инопланетянина на половину шага движения
        game_score += 1 # увеличение счета игры на 1, так как ракета попала в инопланетянина

game_over_text = game_font.render("увы и ах: игра окончена", True, 'white')  # создание надписи, что игра закончена
game_over_rectangle = game_over_text.get_rect()  # создание прямоугольника для надписи
game_over_rectangle.center = (screen_width / 2, screen_height / 2)  # размещение прямоугоника по центу экрана
screen.blit(game_over_text, game_over_rectangle)  # вывод текса с прямоугольником при наступлении флага выхода из цикла
pygame.display.update()  # обновление всех изменений, чтобы игра правильно запустилась
pygame.time.wait(5000)  # надпись находится на экране в течение 5 сек

pygame.quit()  # выход из приложения игры