def print_sum(a, b):
    print(a + b)


my_name = "Dmitry"

a = 10
# print(__name__ == "__main__")  # True
# print(__name__) # __main__


def my_fn():
    pass


# print("main_module_1.py: ", __name__)
# print("main_module_1.py: ", __name__ == "__main__")
