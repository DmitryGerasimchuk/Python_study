c = True


def my_name(name):
    print(name)


print(c)
