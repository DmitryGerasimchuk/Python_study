# Код со второго урока:
# print('Hello, Dmitry!')
# 2+2


# Код с третьего урока:
# print('Hello world!')


# Код с четвертого урока:
# print('Dmitry')
# print(2+2)
# print(True)
# print([1, 2, 'True', False])
# print({'name': "Dima"})

# print('4'+"4")
# print(4+4)

# print(True + True)
# print(False + False)
# print(True)
# print(False)


# Код с пятого урока:
# name = 'Dmitry'
# # print(dir(name))
# print(name.lower())
# print(name.upper())
# print(name)
# name = name.upper()
# print(name)

# Использование функции dir
# print(8, 'Dmitry', True)
# print(print)
# print(input)
# print(dir)
# print()
# print(dir())
# print()
# print(dir(__builtins__))  # вывод встроенных функций в python

# Использование функции input:
# name = input('Напишите свое имя: ')
# print(name)
# print(name.lower())
# print()
# second_name = input('Напишите свою фамилию: ')
# age = input('Сколько Вам лет: ')
# city = input('Напишите из какого Вы города: ')
# print()
# print('Привет, меня зовут',name, second_name, ", я из города", city,', и мне всего ', age)

# print(name.capitalize())
# print(name.upper())

# print(name)
# print(dir(name))


# Код с шестого урока:
# def my_name(name):
#     print(name)
# my_name('Dmitry')

# https://peps.python.org/pep-0008/ - важный документ по оформлению

# my_list = [1, 2, 3]

# print(my_list)
# a = 10


# def my_fn():
#     print('Hello')


# print('Dmitry')


# Код с седьмого урока:
# 10+5
# print(10+5)
# print(print(10+5))

# input('Enter your name: ')
# print(input('Enter your name: '))

# print(def my_fn():
#         print('Dima'))

# print(if True: print(10))

# import datetime

# print(datetime.MAXYEAR)
# print(datetime.MINYEAR)

# print(import datetime)

# def my_func(a, b):
#     a = 1 + 2
#     b = a + 3
#     return b

# # print(return b)
# print(my_func)


# Код с восьмого урока:
# my_age = 36
# print(my_age)
# print(type(my_age))

# my_city = 'Moscow'
# print(my_city)
# print(type(my_city))

# my_example = False
# print(not my_example)
# print(type(my_example))

# my_names = ['Dmitry', 'Dima', 'Dimas']
# print(my_names)
# print(type(my_names))

# my_names = {'1': 'Dima', '2': 'Dmitry'}
# print(my_names)
# print(type(my_names))


# Код с девятого урока:
# def print_name(name):
#     print(name)

# print_name('Dmitry')

# print_name = 36
# print(print_name)

# print_name('Dima')

# неизменяемые типы объектов: int, str, float, bool, tuple, none
# изменяемые типы обхектов: list, dict, set, пользовательские классы

# name = 'Dmitry'
# id(name)
# print(id(name))
# other_name = name
# print(id(other_name))
# # адреса ссылок совпали

# my_name = 'Dima'
# print(id(my_name))

# my_num = 100
# print(id(my_num))

# other_name = my_num
# print(id(other_name))


# Код с десятого урока

# greeting = "Hello from Python!"
# print(greeting)
# print(type(greeting))
# print(id(greeting))
# info_about_me = """Привет!
# Меня зовут Дмитрий.
# Мне 36 лет.
# Я сейчас изучаю Python."""
# print(info_about_me)
# print(type(info_about_me))
# print(id(info_about_me))

# long_str = "This is a very long string"
# print(long_str)
# print(type(long_str))
# print(type(str))
# print(type(int))
# print(id(long_str))
# long_str2 = """This is a
# very
# long
# string"""
# print(long_str2)
# print(type(long_str2))

# print()

# long_str3 = """This is a
# #             very
# #             long
# #             string"""
# # print(long_str3)
# # print(type(long_str3))

# print(len(long_str3))

# my_name = 'Dmitry'
# print(len(my_name))
# print(my_name[0])
# print(my_name[0:3])
# print(my_name[:3])
# print(my_name[3:])
# print(my_name.upper)
# print(my_name.capitalize())
# print(my_name.lower())

# my_comment = "This is my short comment"
# len(my_comment)
# print(len(my_comment))
# my_comment.replace('short', 'long')
# print(my_comment)
# print(my_comment.replace('short', 'long'))
# print(my_comment)

# print(my_comment.count(' '))
# print(my_comment.count('s'))
# print(my_comment.count('s '))

# print(my_comment[0])
# print(my_comment[0:4])
# print(my_comment[-1])
# print(my_comment[-8])
# print(my_comment[-7])
# print(my_comment[5:8])
# print(my_comment[11:])
# print(my_comment[:11])
# print(my_comment[:])

# my_text = "Добрый вечер, мой уважаемый друг"
# print(my_text)
# print(my_text.index('ч'))


# Код с десятого урока
# friends_qty = 50

# print(friends_qty)

# print(type(friends_qty))

# any_num = input("Введите любое числа: ")

# # print(any_num)

# print(type(any_num))  # всегда str (!)

# user_input = input("Enter any number: ")
# any_num = int(user_input)

# print(any_num)

# print(type(any_num))

# any_num = int(input("Enter any number: "))

# print(any_num)

# print(type(any_num))

# base = 5
# power = 3

# print(pow(base, power)) # возведение в степень

# one_million = 1_000_000

# print(one_million)

# my_number = 8_921_083_46_31
# print(my_number)
# print(type(my_number))

# input_str = input("Enter any number: ")
# input_int = int(input_str)

# print(input_int)
# print(type(input_int))

# one_num = 89_31
# two_num = 2
# answer_num = pow(one_num, two_num)

# print(answer_num)
# print(type(answer_num))

# long_int = 8_921_083_46_31
# print(long_int)
# print(type(long_int))

# average_price = 17.75

# print(average_price)

# print(type(average_price))

# print(dir(average_price))

# price = int(average_price) # перевод числа с точкой в целое

# print(price)

# print(type(average_price))

# str_temperature = '36.6'
# temperature = float(str_temperature)

# print(temperature)
# print(type(temperature))

# new_num = 'hello.0'
# num = float(new_num)
# print(type(int)) # ошибка в выводе

# average_price = 17.25
# print(round(average_price))

# average_price = 17.556
# print(round(average_price)) # огругление до ближайшего целого числа int
# print(type(round(average_price)))

# complex_a = 3 + 5j
# print(complex_a)
# print(type(complex_a))

# complex_b = 4 + 8j

# sum = complex_a + complex_b
# print(sum)

# print(type(sum))

# anti_sum = complex_a - complex_b
# print(anti_sum)

# anti_sum = complex_a * 3
# print(anti_sum)

# anti_sum = complex_a ** 5
# print(anti_sum)

# print(complex_a - complex_b)
# print(complex_a * complex_b)


# Код с двенадцатого урока

# is_authorized = True
# print (is_authorized)
# print(type(is_authorized))

# print(100 > 25)
# print(-5 > 0)
# print("Long string" > 'Long')
# print([1, 2, 3] == [1, 3, 6])

# db_is_available = False
# print(db_is_available)
# print(type(db_is_available))

# db_is_available = True
# print(db_is_available)

# print(bool(10))
# print(bool('abc'))
# print(bool([]))
# print(bool([1, 2]))
# print(bool(None))
# print(bool({}))

# print(36 < 37)
# print('Long' != 'Short')
# print([4] == [5])
# print({'a': 3} == {'a':2})


# Код с тринадцатого урока
# print('10' + 5)
# print(5 + '10')
# print(5 + int('10'))
# # print(str(5) + '10')
# int_num = 5
# float_num = 4.5
# print(int_num + float_num)

# int_num = 5
# float_num = 4.5
# print(float_num + int_num)

# bool_val = True
# int_val = 7
# print(bool_val + int_val)

# bool_val = False
# int_val = 7
# print(bool_val + int_val)

# bool_val = True
# int_val = 7
# print(int_val + bool_val)

# int_num = 50
# float_num = 7.5
# str_val = 'abc'
# print(int_num * float_num)
# print(int_num.__mul__(float_num))
# print(float_num.__rmul__(int_num))
# print(int_num * str_val)
# print(str_val * int_num)
# print(int_num.__mul__(str_val))
# print(str_val.__rmul__(int_num))
# print(float_num * str_val)
# print(str_val * float_num)
# print(float_num.__mul__(str_val))
# print(str_val.__rmul__(float_num))

# print(bool)
# print(bool(10))
# print(dir(bool))
# print(bool.__doc__)
# print(str.__doc__)
# my_list = []
# print(help(my_list.__eq__))
# print(help(list.__eq__ ))


# Код с четырнадцатого урока: списки

# my_fruits = ['apple', 'banana', 'lime']
# other_fruits = ['banana', 'apple', 'lime']
# print(my_fruits == other_fruits)
# a = 'Dima'
# empty_list = []
# print(len(a))
# print(len(my_fruits))
# print(len(empty_list))
# print(my_fruits[2])
# print(other_fruits[-1])
# other_fruits[0] = 'new_banana'
# print(other_fruits)

# print(len(other_fruits))
# del other_fruits[0]
# print(other_fruits)
# print(len(other_fruits))

# users = [
#     {
#         'user_id': 1,
#         'user_name': 'Dmitry',
#         'user_sirname': 'Gerasimchuk'
#     },
#     {
#         'user_id': 2,
#         'user_name': 'Svaitoslav',
#         'user_sirname': 'Dichenkov'
#     }
# ]
# print(users)
# print(len(users))
# print(users[1]['user_id'])

# first_name = "Dima"
# second_name = "Dimas"
# third_name = "Dmitry"

# all_names = [first_name, second_name, third_name, first_name]

# print(all_names)
# print(len(all_names))

# print(all_names[6])
# print(dir(all_names))
# all_names.append('Dimasik')
# print(len(all_names))
# print(all_names)

# all_names.pop()
# print(all_names)

# all_names.pop(2)
# print(len(all_names))

# old_name = all_names.pop(0)
# print(old_name)
# print(all_names)

# print(all_names)
# all_names.sort()
# print(all_names)
# all_names.sort(reverse=True)
# print(all_names)

# first_program = 'Hello world!'
# print(first_program)
# print(type(first_program))

# first_program_list = list(first_program)
# print(first_program_list)
# print(type(first_program_list))
# print(first_program_list[-1])
# print(len(first_program_list))

# my_dict = {'age':37, 'name':'Dmitry'}
# print(my_dict)
# print(type(my_dict))

# my_dict_key = list(my_dict)
# print(my_dict_key)
# print(type(my_dict_key))

# from numpy import add

# numbers = [2, 3, 6, 45, 89]
# print(max(numbers))
# print(min(numbers))
# print(sum(numbers))
# print(sum(numbers)/len(numbers))

# other_numbers = [0, 4, 7, 88]
# all_numbers = numbers + other_numbers
# print(all_numbers)
# new_all_numbers = all_numbers.sort(reverse=True)
# print(new_all_numbers)
# all_numbers_first = all_numbers[:3]
# print(all_numbers_first)

# all_numbers_second = all_numbers[5:-1]
# print(all_numbers_second)

# all_numbers_third = all_numbers[-4:]
# print(all_numbers_third)
# all_numbers_four = all_numbers[:]
# print(all_numbers_four)

# numbers = [2, 3, 6, 45, 89]
# other_numbers = [0, 4, 7, 88]
# print(id(numbers))
# print(id(other_numbers))

# new_numbers = numbers
# new_numbers_ver = numbers[:] # копирование используя нарезку
# print(id(new_numbers))
# print(id(new_numbers_ver))

# new_numbers_ver.append(34)
# print(numbers)

# new_numbers = numbers.copy() # копирование с помощью метода copy
# print(new_numbers)
# print(id(new_numbers))

# new_numbers = list(numbers) # копирование с помощью метода list
# print(new_numbers)
# print(id(new_numbers))

# my_nums = [10, 50, 0, 5, 0, 100]
# print(my_nums)
# print(type(my_nums))
# print(dir(my_nums))
# print(my_nums.count(0))
# zero = my_nums.count(0)
# print(zero)
# my_nums.append(37)
# print(my_nums)
# my_nums.insert(4, -1)
# print(my_nums)
# my_nums.clear()
# print(my_nums)
# my_nums.extend('Dimas')
# print(my_nums)
# other_nums = my_nums
# print(id(my_nums) == id(other_nums))
# other_nums = my_nums.copy()
# print(id(my_nums) == id(other_nums))

# my_nums.append(0)
# other_nums.clear()
# print(my_nums, other_nums)

# other_nums = my_nums[:]
# print(id(my_nums) == id(other_nums))

# my_nums.append(0)
# other_nums.clear()
# print(my_nums, other_nums)

# other_nums = list(my_nums)
# print(id(my_nums) == id(other_nums))

# my_nums.append(0)
# other_nums.clear()
# print(my_nums, other_nums)

# print(len(my_nums))


# Код с пятнадцатого урока: словари
# about_me_1 = {
#     'name': 'Dmitry',
#     'sirname': 'Gerasimchuk',
#     'age': 37,
#     'city': 'Moscow',
# }

# about_me_2 = {
#     'sirname': 'Gerasimchuk',
#     'name': 'Dmitry',
#     'age': 37,
#     'city': 'Moscow',
# }

# print(about_me_1 == about_me_2)
# print(id(about_me_1) == id(about_me_2))

# print(about_me_1['sirname'])
# print(about_me_1['city'])
# print(dir(about_me_1['name']))

# about_me_1['name'] = 'Dima'
# print(about_me_1)

# about_me_1['name'] = 'Dmitry'
# about_me_1['nationality'] = 'Pomor'

# print(about_me_1)

# del about_me_1['nationality']
# print(about_me_1)

# second_name = 'sirname' # изменение значение в словаре через переменную
# print(second_name)
# about_me_1[second_name] = 'Gerasimovich'
# print(about_me_1)

# new_second_name = 'sirname'
# about_me_1[new_second_name] = 'Gerasimchuk'
# print(about_me_1)

# about_me_1 = {
#     'name': 'Dmitry',
#     'sirname': 'Gerasimchuk',
#     'age': 37,
#     'city': 'Moscow',
#     'phone_info': {
#         'megafon': 89261771539,
#         'yota': 89210834631,
#     }
# }

# print(about_me_1)
# print()
# print(about_me_1['phone_info']['megafon'])
# print(about_me_1['phone_info']['yota'])

# my_name = 'Dmitry'
# my_age = 30
# born_city = 'Arhkangelsk'

# about_me_3 = {
#     'name': my_name,
#     'age': my_age,
#     'city': born_city,
# }

# print(about_me_3)
# print(len(about_me_3))
# print()

# del about_me_3['city']
# print(len(about_me_3))
# print(about_me_3)
# print()

# about_me_4 = {}
# print(len(about_me_4))

# print(about_me_3)
# print(about_me_3['age'])
# print(about_me_3['sirname'])
# print(about_me_3.get('age'))
# print(about_me_3.get('sirname'))
# print(about_me_3.get('sirname', 'ну нет такого!'))

# print(about_me_3.__doc__)

# my_family ={}

# print(id(my_family))
# print(type(my_family))

# my_family['second_name'] = 'Gerasimchuk'
# my_family['first_name'] = 'Dmitry'

# print(my_family)
# print(id(my_family))

# print(my_family.__doc__)

# print(my_family.items())
# print(type(my_family.items()))

# print(my_family.keys())
# print(type(my_family.keys()))
# list_family = list(my_family.keys())
# print(list_family)

# print(my_family.popitem()) # не рекомендуют использовать, так как удаляется последний добавленный ключ
# print(my_family)
# print()

# print(my_family.get('first_name', 'Ты же его удалил уже!'))

# new_my_family = my_family.copy()
# new_my_family['first_name'] = "Dima"

# print(my_family)
# print(new_my_family)m
# print(id(my_family))
# print(id(new_my_family))

# print(len(new_my_family))

# my_list = ['Gerasimchuk', 'Dmitry', 37, True]
# my_dict = dict(my_list)
# print(my_dict) #  ошибка

# my_list = [['second_name','Gerasimchuk'], ['first_name', 'Dmitry'], ['age', 30]]
# my_dict = dict(my_list)
# print(my_dict) #создание словаря через списки

# my_list = [('second_name','Gerasimchuk'), ['first_name', 'Dmitry'], ['age', 30]]
# my_dict = dict(my_list)
# print(my_dict) # создание словаря через кортеж

# my_str = 'Gerasimchuk'
# my_dict = dict(my_str)
# print(my_dict) #  ошибка


# Код с шестнадцатого урока: кортежи
# my_name = ('Dmitry', 'Dima', 'Dimas')
# # print(type(my_name))
# # print(my_name)
# another_name = ('Dima', 'Dimas', 'Dmitry')
# print(my_name == another_name)
# print(len(another_name))

# print(my_name[2])

# # my_name[2] = 'Mitya' # ошибка
# del my_name[2] # ошибка: удалять нельзя

# my_family = (
#     {
#         'id': 1,
#         'name': 'Dmitry',
#     },
#     {
#         'id': 2,
#         'name': 'Bonya',
#     },
# )
# print(my_family)
# print(type(my_family))

# print(my_family[1]['name'])

# my_family[1]['name'] = 'Slava'
# print(my_family)

# my_name = 'Dmitry'
# my_age = 37
# my_city = 'Moscow'

# about_me = (my_name, my_age, my_city)
# print(about_me)
# print(type(about_me))

# print(about_me[0])
# # print(about_me[6]) # ошибка

# my_names = ('Dmitry', 'Dima', 'Dimas')

# all_info = about_me + my_names
# print(all_info)

# my_names = ('Dmitry', 'Dima', 'Dimas', 'Dima', 'Dima')
# print(my_names.count('Dmitry'))
# print(my_names.count('Dima'))

# print(my_names.index('Dmitry'))
# print(my_names.index('Dima'))

# my_names_list = list(my_names)
# print(type(my_names_list))
# print(my_names_list)

# my_names_list.pop(-1)
# my_names_list.pop(-1)
# print(my_names_list)

# my_names_tuple = tuple(my_names_list)
# print(my_names_tuple)
# print(type(my_names_tuple))

# y_names = ('Dmitry', 'Dima', 'Dimas', 'Dima', 'Dima')
# print(my_names.count('Dima'))
# print(my_names.index('Dima'))
# index_one = my_names.index('Dima')
# print(index_one)

# index_two = my_names.index('Dima', index_one)
# print(index_two)

# index_two_another = my_names.index('Dima', index_two + 1)
# print(index_two_another)

# index_three_another = my_names.index('Dima', index_two_another + 1)
# print(index_three_another)

# my_names = ('Dmitry', 'Dima', 'Dimas', 'Dima', 'Dima')
# my_names_list = list(my_names)
# print(my_names_list)
# print(type(my_names_list))

# my_names_list.append('Dimon')
# print(my_names_list)

# my_names = tuple(my_names_list)
# print(my_names)

# my_tuple = tuple('abcd')
# print(my_tuple) # в кортеж попадают буквы как элементы
# print(type(my_tuple))

# my_tuple = tuple({'first': 1, 'second': 2})
# print(my_tuple) # в кортеж попадают только ключи
# print(type(my_tuple))


# Код со семнадцатого урока: наборы
# my_names = {'Dmitry', 'Dima', 'Dimas', 'Dmitry'} # удаляются дубликаты
# print(type(my_names))
# print(my_names)

# new_my_names = {'Dmitry', 'Dima', 'Dimas'}
# print(my_names == new_my_names)

# print(len(my_names))
# # print(new_my_names[0]) # нет индексов

# new_my_names_list = ['Dmitry', 'Dima', 'Dimas']
# print(new_my_names_list.__getitem__(1))
# print(new_my_names_list[1])

# # a = 12
# # print(a[0]) # ошибка

# list_set = {[1, 2], [20, 5]} # ошибка
# print(list_set)

# tuple_set = {(1, 2), (20, 5)}
# print(tuple_set)
# del tuple_set[0] # не поддерживается - ошибка

# my_set = {10, 10, 5, 15, 15}
# print(my_set)
# print(len(my_set))

# del my_set[1] # ошибка

# my_set = {[10, 10], 5, 15, 15} # ошибка
# print(my_set)
# print(len(my_set))

# my_set = {(10, 10), 5, 15, 15}
# print(my_set)
# print(len(my_set))

# my_set = {{10: 10}, 5, 15, 15} # ошибка
# print(my_set)
# print(len(my_set))

# my_set = set()
# print(type(my_set))

# my_names = {'Dmitry', 'Dima', 'Dimas', 'Dmitry'} # удаляются дубликаты
# print(dir(my_names))
# my_names.add('Dimon')
# print(my_names)

# other_names = {'Slava', 'Andrey', 'Dimas'}
# names = my_names.union(other_names)
# names = my_names|other_names
# print(names)

# names = my_names.intersection(other_names)
# names = my_names & other_names
# print(names)

# res = other_names.issubset(my_names)
# print(res)

# my_set = {'abc', 'd', 'ef', 'j', 'y'}
# other_set = {'a', 'ef', 'd'}

# print(my_set.intersection(other_set))
# print(other_set.intersection(my_set))

# print(other_set.intersection('abcdef'))
# print(other_set.intersection(['a'], ['b'], ['c'], ['d'], ['e'], ['f']))
# print(other_set.intersection(('a', 'b', 'c', 'd')))
# print(other_set.intersection(['a', 'b', 'c', 'd']))

# print(my_set.union(other_set))
# print(other_set.issubset(my_set))
# print(my_set.issubset(other_set))

# new_other_set = {'a', 'ef', 'd'}
# print(other_set.issubset(new_other_set))
# print(other_set.issubset(new_other_set))
# print(other_set == new_other_set)

# print(my_set.difference(other_set))
# print(my_set - other_set)
# print(my_set & other_set)
# print(my_set | other_set)

# print(my_set.discard('abc')) # удаление элемента
# print(my_set)

# my_set.discard('abe')
# print(my_set)
# my_set.remove('abc')
# print(my_set)

# copied_set = my_set.copy()
# print(id(my_set), id(copied_set))

# my_set.add('yes')
# copied_set.add('no')
# print(my_set)
# print(copied_set)

# print(my_set & copied_set)
# print(my_set.symmetric_difference(copied_set))
# print((my_set | copied_set) - (my_set & copied_set))


# Код с восемнадцатого урока: диапазоны
# my_range = range(9)
# print(my_range)
# print(type(my_range))
# print(list(my_range))

# my_range = range(3, 9, 2)
# print(type(my_range))
# print(my_range)
# print(list(my_range))

# print(my_range[0])
# print(my_range[1])
# print(my_range[2])
# print(my_range[3])

# for i in my_range:
#     print(i)

# for i in range(3, 9, 3):
#     print(i)

# my_range = range(5)
# print(my_range)
# print(type(my_range))
# print(my_range[3])
# print(my_range[-1])

# for i in my_range:
#     print(i**3)

# print(my_range[3])

# for i in range(4):
#     print(i**3)

# for i in range(7, 12):
#     print(i)

# for i in range(5, 100, 20):
#     print(i)

# print(list(range(5, 100, 20)))
# print(tuple(range(5, 100, 20)))
# print(set(range(5, 100, 20)))
# print(str(range(5, 100, 20)))
# # print(int(range(5, 100, 20))) # ошибка
# print(dict(range(5, 100, 20))) # ошибка

# my_range = range(4, 8, 2)
# print(list(my_range))

# print(dir(my_range))
# print(my_range.start)
# print(my_range.stop)
# print(my_range.step)

# print(my_range.index(6))
# # print(my_range.index(8))

# print(my_range.count(6))
# print(my_range.count(8))


# Код с девятнадцатого урока: функция zip
# names = ['Dima', 'Slava', 'Ira', 'noname']
# age = (37, 40, 36, 18)
# # city = ('Arkhangelsk', 'Vologda', 'Moscow')
# # letters = 'abcd'
# # family = zip(letters, names, age, city)
# family = zip(names, age)
# print(family)
# print(type(family))

# # print(tuple(family))
# # print(list(family))
# print(dict(family))


# Код с двадцатого урока: изменение объектов в Python
# my_age = 37
# print(id(my_age))

# your_age = 37
# print(id(your_age))

# print(id(37))

# dimas_age = my_age
# print(id(dimas_age))

# dimas_age += 1
# print(my_age)
# print(dimas_age)

# print(id(my_age))
# print(id(dimas_age))

# my_list = [1, 3, 5]
# print(id(my_list))

# other_list = [1, 3, 5]
# print(id(other_list))

# print(id([1, 3, 5]))

# other_list.append(7)
# print(other_list)
# print(id(other_list))

# print()

# new_other_list = my_list
# print(new_other_list)
# print(id(new_other_list))
# new_other_list.append(6)
# print(id(my_list), id(new_other_list))
# print(my_list, new_other_list)

# info = {
#     'name': 'Dmitry',
#     'age': 37,
# }

# info_Dm = info
# print(id(info), id(info_Dm))

# info['town'] = 'Moscow'
# print(info_Dm)

# info_Dm['town'] = 'Arkhangelsk'
# print(info_Dm)
# print(info)

# info = {
#     'name': 'Dmitry',
#     'age': 37,
# }

# info_Dm = {
#     'name': 'Dmitry',
#     'age': 37,
# }

# print(id(info), id(info_Dm))

# info_Dm['city'] = 'Moscow'
# # print(info, info_Dm)

# new_info_Dm = info_Dm.copy() # важный метод копирования, когда не можно изменять копию без изменения оригинала
# print(id(info_Dm), id(new_info_Dm))
# new_info_Dm['city'] = 'Arkhangelsk'
# print()
# print(new_info_Dm)
# print(info_Dm)

# info ={
#     'name': 'Dmitry',
#     'age': 37,
#     'phone_number': [],
# }

# info_Dm = info.copy()
# print(id(info) == id(info_Dm))

# # info_Dm['phone_number'].append(89210834631)
# info_Dm['phone_number'] = 89210834631
# print(info_Dm)
# print(info)

# info ={
#     'name': 'Dmitry',
#     'age': 37,
#     'phone_number': [],
# }

# from copy import deepcopy # модуль для глубокого копирования

# info_deepcopy = deepcopy(info)
# print(id(info) == id(info_deepcopy))

# info_deepcopy['phone_number'].append(89210834631)
# print(info_deepcopy)
# print()
# print(info)


# Код с двадцать первого урока: функции
# a = 19
# b = 1
# c = a + b
# print(c)


# def sum(i, j):
#     k = i + j
#     print(k)


# a = 19
# b = 1
# sum(a, b)

# a = -1
# b = 0
# sum(a, b)
# print(type(sum))
# # print(dir(sum))


# def my_fn():
#     pass # ключевое слово, которое ничего не делает

# print(my_fn())


# def my_fn(a, b):
#     a = a * 3
#     c = a**b
#     print(id(a), id(b), id(c))
#     return c


# num_a = 3
# num_b = 2

# res = my_fn(num_a, num_b)
# print(res)
# print(id(num_a), id(num_b))
# print(num_a, num_b)


# def ages_person(person):
#     person["age"] += 3
#     print(id(person))
#     print(type(person))
#     return person


# # print(person)

# my_age_person = {
#     "name": "Dmitry",
#     "age": 37,
# }

# print(id(my_age_person))

# ages_person(my_age_person)
# print(ages_person)
# print(my_age_person["age"])  # изменилось значение 37->40
# print(id(my_age_person))
# print(type(my_age_person))


# def ages_person(person):
#     person_copy = person.copy()
#     person_copy["age"] += 3
#     print(id(person))
#     print(id(person_copy))
#     return person_copy


# # print(person)

# my_age_person = {
#     "name": "Dmitry",
#     "age": 37,
# }

# print(id(my_age_person))

# new_my_age_person = ages_person(my_age_person)
# print(new_my_age_person)
# print(my_age_person["age"])  # не изменилось значение 37->37
# print(id(my_age_person))
# print(id(new_my_age_person))


# Код с двадцать второго урока: аргументы функции
# def sum_nums(a, b):
#     c = a + b
#     return c


# nums_one = 19
# nums_two = 21

# print(sum_nums(nums_one, nums_two))
# # print(sum_nums(nums_one))
# print(sum_nums)
# # print(sum_nums())

# # print(sum_nums(nums_one, nums_two, 3))
# # print(sum_nums(3, 3, 3))


# def sum_nums(*args):
#     print(args)
#     print(type(args))
#     # print(args[2])
#     return sum(args)


# print(sum_nums(1, 3, 5, 7, 9))
# print()
# print(sum_nums(2, 4, 6, 8, 10))
# print()
# print(sum_nums())


# def my_text(name, nums_post):
#     info = f"{name} уже написал {nums_post} постов в этом году."
#     return print(info)


# information = my_text("Дмитрий", 9)
# information_new = my_text(nums_post=67, name="Slava")
# # information_new_2 = my_text(name="Slava", 56)


# def info_post(**person):  # создание из параметров словаря
#     print(person)
#     print(type(person))
#     info = f"{person['name']} написал " f"{person['nums']} постов"
#     return info


# info_about_me = info_post(name="Дмитрий", nums=67, id=98)
# print(info_about_me)


# Код с двадцать третьего урока: параметры функции по умолчанию
# def mult_by_factor(value, multiplier=1):
#     return value * multiplier


# print(mult_by_factor(15, 67))
# print(mult_by_factor(89))

# from datetime import date


# def get_weekday():
#     return date.today().strftime("%A, %d. %B %Y %I:%M%p")


# def create_new_post(post, weekday=get_weekday()):
#     post_copy = post.copy()
#     post_copy["created_on_weekday"] = weekday
#     return post_copy


# initial_post = {
#     "id": 234,
#     "author": "Dmitry",
# }

# post_with_weekday = create_new_post(initial_post)
# # post_with_weekday = create_new_post(initial_post, "Sunday")
# # post_with_weekday = create_new_post(post=initial_post, weekday="I don't know")

# print(post_with_weekday)
# print(initial_post)


# Код с двадцать четвертого урока: колбэк функции
# def print_number_info(num):
#     if (num % 2) == 0:
#         print("Entered number is even")
#     else:
#         print("Entered number is odd")


# def print_square_num(num):
#     print("Square of the num is ", num * num)


# def process_number(num, callback_fn):
#     callback_fn(num) # изолирование функции


# entered_num = int(input("Enter any number: "))

# process_number(entered_num, print_number_info)
# process_number(entered_num, print_square_num)


# Код с двадцать пятого урока: как работать с функциями
# def mult_by_factor(value, mult=1):
#     """Тут нужно на английском языке писать, что делает функция. Именно эта функция перемножает два аргумента"""
#     return value * mult


# result = mult_by_factor(6, 3)
# print(result)


# def print_number_info(num):
#     """
#     Prints whether number is even or odd

#     Args:
#         num (int): number to be evaluated
#     """
#     if (num % 2) == 0:
#         print("Entered number is even")
#     else:
#         print("Entered number is odd")


# print_number_info(7)

# def print_number_info(num):
#     """
#     Описание функции

#     Args:
#         num (int): описание аргумента/ов

#     Returns:
#         int: описание, что возвращается по результату запуска
#     """
#     if (num % 2) == 0:
#         print("Entered number is even")
#     else:
#         print("Entered number is odd")
#     return num

# print_number_info(7)

# a = 12


# def my_fn():
#     a = 7
#     b = "Hello"
#     print(a)
#     print(b)


# my_fn()
# print()

# print(a)
# # print(b)

# a = 5


# def my_fn():
#     def inner_fn():
#         print(a)

#     inner_fn()


# my_fn()

# a = 678


# def my_fn():
#     global a
#     a = 10
#     b = 9
#     print(a + b)


# # my_fn() # присвоение нового значения происходит только при вызове функции

# print(a)
# # print(b)

# c = "Oh!"


# def my_fn(a, b):
#     d = "None"
#     print(c, a, b)
#     print(dir())  # просмотр всех переменных, созданных в локальной области


# my_fn("Dimas", "don't stop to prorgamming!")

# # print(a)
# # print(b)
# # print(c)
# # print(dir())  # просмотр всех переменных, созданных в глобальной области


# Код с двадцать шестого урока: операторы
# a = 10
# # b = a
# b = 10

# c = a + b

# print(a is b)  # id(a) == id(b)
# print(c is b)

# a = [1, 2]
# b = [1, 2]

# # print(a=b)
# print(a == b)
# print(a.__eq__(b))
# print(a is b)  # id(a) != id(b)
# print(a.__eq__)
# print(b.__eq__)
# print()
# print(hex(id(a)))

# print(a.__gt__(b))

# a = 10
# b = 20
# c = True
# d = False
# print(-a)
# print(+b)
# print(+c)
# print(+d)
# print(not a)
# print(not d)

# my_car = {
#     "brand": "Toyota",
#     "price": 10_000_000,
# }

# print("price" in my_car)
# print("self" in my_car)
# print("self" not in my_car)

# my_set = (45, 78, 90)

# print(98 in my_set)
# print(90 in my_set)

# print(bool(0))
# print(bool(0.0))
# print(bool(0j))
# print(bool(None))
# print(False)
# print()

# print(bool([]))
# print(bool(""))
# print(bool({}))
# print(bool(()))
# print(bool(set()))
# print(bool(range(0)))
# print()

# # проверка ложности через двойное отрицание:
# print(not not 0)
# print(not not 0.0)
# print(not not 0j)
# print(not not None)
# print(not not False)
# print()
# print(not not [])
# print(not not "")
# print(not not {})
# print(not not ())
# print(not not set())
# print(not not range(0))
# print()

# print(not not {"a": 1})

# my_list = [1, 2]
# # my_list = []
# # print(len(my_list) > 0)

# # if len(my_list) > 0:
# #     print("Идем дальше!")

# if my_list: # равносильно if len(my_list) > 0
#     print("Идем дальше!")


# Код с двадцать седьмого урока: логические операторы
# print(not 10)
# print(not 0)
# print(not "Dima")
# print(not "")
# print(not True)
# print(not None)
# print()

# print(not not 10)
# print(not not 0)
# print(not not "Dima")
# print(not not "")
# print(not not True)
# print(not not None)

# my_list = []
# my_list = [1, 3]
# print(not not my_list)

# other_list = ["a", "b"]
# # print(my_list or other_list)  # возвращение первого правдивого выражения
# print(len(my_list) > 0 or other_list)  # возвращение первого правдивого выражения
# print(len(my_list) < 0 or other_list)
# my_dict = {}
# my_dict = {"a": 5}

# print(my_list and my_dict)
# print(bool(my_list and my_dict))

# my_list = []
# my_list = [1, 3]

# my_list and print("List is not empty")


# Код с двадцать восьмого урока: оператор распаковки словаря
# button = {
#     "width": 200,
#     "text": "Buy",
# }

# button = {"width": 200, "text": "Buy", "color": "green", "name": "Oops"}

# button_green = {
#     "width": 200,
#     "text": "Buy",
#     "color": "green",
# }

# button = {
#     "width": 200,
#     "text": "Buy",
#     "name": "Oops",
#     "color": "green",
# }

# red_button = {
#     **button,
#     "color": "red",
# }

# red_button = {
#     "color": "red",
#     **button_green,
# }

# print(button)
# print()
# print(button_green)
# print()
# print(red_button)

# button_info = {
#     "text": "Buy",
# }

# button_info_1 = {
#     "text": "Buy",
#     "color": "red",
# }

# button_style = {
#     "color": "yellow",
#     "wight": 200,
#     "height": 300,
# }

# # button = {**button_info_1, **button_style}
# button = (
#     button_info_1 | button_style
# )  # место указания словарей в обоих случаях имеет значение

# print(button)
# # print(button_info_1)
# # print(button_style)


# Код с двадцать девятого урока: инструкция del
# my_dict = {
#     "a": True,
#     "b": 10,
# }

# print(my_dict)

# del my_dict["a"]
# print(my_dict)

# my_dict.__delitem__("b")
# print(my_dict)

# print(my_dict.__delitem__)

# my_list = [1, 2, 4, 5]

# del my_list[0]
# # print(del my_list[0]) # ошибка
# print(my_list)

# my_list.__delitem__(2)
# print(my_list)


# Код с тридцатого урока: соединение строк
# print("Hello " + "world" + "!")
# word1 = "Hello"
# word2 = "world"
# print(word1 + " " + word2 + "!")

# greeting = f"Стандартное приветствие: {word1} {word2}!"
# print(greeting)

# my_name = "Dmitry"
# my_hobby = "reading books"
# time = 23

# info = my_name + " likes " + my_hobby + " at " + str(time) + " o'clock "
# # info = my_name + " likes " + my_hobby + " at " + time + " o'clock" # ошибка
# info_2 = my_name + " likes " + my_hobby + " at " + str(time) + " o'clock"

# print(info)
# print(info_2)

# info = f"{my_name} likes {my_hobby} at {time} o'clock"
# info_1 = f"{my_name} likes {my_hobby} at {str(time)} o'clock"
# info_2 = f"{my_name} likes {my_hobby} at {[8, 0]} o'clock"

# print(info_2)


# Код с тридцать первого урока: лямбда функции
# def mult(a, b):
#     return a * b

# print(mult(5, 3))

# mult_1 = lambda a, b: a * b # не рекомендуеся присваивать переменнным
# print(mult_1(5, 7))


# def greeting(greet):
#     return lambda name: f"{greet}, {name}!"


# morning_greeting = greeting("Good morning")
# print(morning_greeting)
# print(morning_greeting("Dmitry"))
# print()

# day_greeting = greeting("Have a good day")
# print(day_greeting("Dmitry"))  # называется замыкание


# def greeting_another(greet):
#     def info(name):
#         return f"{greet}, {name}!"

#     return info


# first_greeting = greeting_another("Good evening")
# print(first_greeting("Dima"))


# Код с тридцать второго урока: обработка ошибок
# print(10 / 0) #ZeroDivisionError: division by zero
# print("Continue...")

# try:
#     print(10 / 0)
#     # print(10 / 5)
#     # print(10 + "5")
# except ZeroDivisionError:  # обработка конкретного типа ошибки
#     print("Ёлки-волки! Ошибка деления на ноль")
#     print(ZeroDivisionError)

# print("Continue...")

# try:
#     print(10 / 0)
# except ZeroDivisionError as e:  # получение доступа к ошибке
#     # print(type(e))
#     # print(dir(e))
#     # print(e)
#     print(e.__str__())
# except TypeError as e:
#     print(e)
#     print(type(e))
# else:
#     print("Ура! Ошибок в коде нет")
# finally:  # выполняется блок независимо от возникновения ошибки
#     print("Continue...")

# try:
#     print(10 / 0)
# except Exception as e:  # есть доступ к ошибке
#     print(e)
#     # print(isinstance(e, ZeroDivisionError))
#     # print(isinstance(e, Exception))
#     print(isinstance(e, object))
# finally:
#     print("Let's go!")

# try: # не рекомендуется, так как нет доступа к оишбке
#     print(10 / 0)
# except:
#     print("Что-то пошло не так")
# finally:
#     print("А что дальше?")


# def divide_nums(a, b):
#     if b == 0:
#         raise ValueError("Second argument can't be 0")
#     return a / b


# try:
#     divide_nums(10, 0)
# except ZeroDivisionError as e:
#     print(e)
# # except ValueError as e:
# #     print(e)
# except Exception as e:
#     print(e)

# print("Continue...")


# Код с тридцать третьего урока: распаковка списков и кортежей
# my_fruits = ["apple", "banana", "lime"]
# my_apple = my_fruits[0]
# my_banana = my_fruits[1]
# my_lime = my_fruits[2]

# # print(my_apple, my_banana, my_lime)

# # apple, banana, lime = my_fruits # распаковка
# # print(apple, banana, lime)

# apple, banana, lime, lemon = my_fruits
# print(apple, banana, lime, lemon) # ошибка

# my_fruits = ("apple", "banana", "lime")
# print(type(my_fruits))

# apple, banana, lime = my_fruits
# print(apple)
# print(banana)
# print(lime)
# print(type(apple))

# my_name = ["Dima", "Dmitry", "Dimas"]
# my_small_name, *other_names = my_name

# print(my_small_name)
# print(other_names)

# print(type(my_name))
# print(type(my_small_name))
# print(type(other_names))

# user_profile = {
#     "name": "Dmitry",
#     "comments_qty": 37,
# }  # если добавить еще строку ("id": 234,), получим ошибку


# def user_info(name, comments_qty=0):
#     if not comments_qty:
#         return f"{name} has no comments"
#     return f"{name} has {comments_qty} comments"


# first, second = (
#     user_profile  # при распаковке словарей таким образом, получаем ключи (без значений)
# )
# print(first)
# print(second)

# # print(user_info(**user_profile)) # распаковка словаря только с **
# # print(user_info(user_profile))  # неправильная передача знания
# # print(user_info(user_profile["name"], user_profile["comments_qty"])) # передача позиционных аргументов
# print(
#     user_info(name=user_profile["name"], comments_qty=user_profile["comments_qty"])
# )  # передача именнованных аргументов

# user_data = ["Dmitry", 37]
# # user_data = ["Dmitry", 37, Moscow] #ошибка


# def user_info(name, comments_qty):
#     if not comments_qty:
#         return f"{name} has no comments"
#     return f"{name} has {comments_qty} comments"


# my_name, my_num = user_data

# # print(user_info(user_data)) # ошибка
# # print(user_info(*user_data))
# # print(user_info(**user_data)) # ошибка

# # print(user_info(user_data[0], user_data[1]))
# # print(user_info(name=user_data[0], comments_qty=user_data[1]))

# print(user_info(my_name, my_num))


# Код с тридцать четвертого урока: условные инструкции
# my_number = 9

# if my_number > 0:
#     print(my_number, "- число явно большее нуля.")

# person_name = {
#     "first_name": "Dmitry",
#     "last_name": "Gerasimchuk",
# }

# # if not person_name.get("first_name"):
# #     print("В словаре нет имени")
# if not person_name.get("age"):
#     print("В словаре нет информации о возрасте")

# if 10 > 2:
#     print(True)
# if 10 > 2:
#     print(True)
# if 10 > 2:
#     print(True)

# one_num = 10
# # two_num = 8.0
# two_num = 8
# if (
#     one_num > 0
#     and two_num > 0
#     and isinstance(one_num, int)
#     and isinstance(two_num, int)
# ):
#     print("Both numbers are positive and ints")

# my_number = 10.7
# my_number = 10

# if type(my_number) is int:
#     print("My number is int")
# else:
#     print("My number is not int")


# my_phone = {
#     "price": 169_000,
#     "brand": "iPhone 15",
# }

# if my_phone.get("brand"):
#     print("Phone's brand is", my_phone["brand"])
# else:
#     print("There is no phone brand")

# print(my_phone.get("brand"))
# print(bool(my_phone.get("brand")))

# my_number = -10

# if my_number > 0:
#     print(my_number, "is positive number")
# elif my_number < 0:
#     print(my_number, "is negative number")
# else:
#     print(my_number, "is zero")


# def nums_info(a, b):
#     if (type(a) is not int) or (type(b) is not int):
#         return "Один из аргументов не целое число"

#     if a >= b:
#         return f"{a} больше или равно {b}"

#     return f"{a} меньше {b}"


# def nums_info(a, b):
#     if (type(a) is not int) or (type(b) is not int):
#         info = "Один из аргументов не целое число"
#     elif a >= b:
#         info = f"{a} больше или равно {b}"
#     else:
#         info = f"{a} меньше {b}"
#     return info


# print(nums_info(None, "Hello"))
# print(nums_info(8, 9))
# print(nums_info(7.9, 8))


# Код с тридцать пятого урока: тернарные операторы
# my_number = 21.5

# (
#     print(f"{my_number} is int")
#     if type(my_number) is int
#     else print(f"{my_number} is not int")
# )

# if type(my_number) is int:
#     print(f"{my_number} is int")
# else:
#     print(f"{my_number} is not int")

# product_qty = 10

# print("in stock" if product_qty > 0 else "out of stock")

# temp = +21

# weather = "hot" if temp > 18 else "cold"
# print(weather)

# my_img = ("1920", "1080")

# (
#     print(f"{my_img[0]} x {my_img[1]}")
#     if len(my_img) == 2
#     else print("Incorrect image formatting")
# )

# answer = (
#     f"{my_img[0]} x {my_img[1]}" if len(my_img) == 2 else f"Incorrect image formatting"
# )
# print(answer)

# if len(my_img) == 2:
#     print(f"{my_img[0]} x {my_img[1]}")
# else:
#     print("Incorrect image formatting")

# my_str = "Привет, Дмитрий!"

# (
#     print(f"Строка '{my_str}' is long")
#     if len(my_str) > 79
#     else print(f"Строка '{my_str}' is short")
# )


# Код с тридцать шестого урока: цикл for in
# i = 10

# print(i)
# i *= 2

# print(i)
# i *= 2

# print(i)

# my_fruits = ["apple", "banana", "lime"]
# print(my_fruits[0])
# print(my_fruits[1])
# print(my_fruits[2])

# my_dict = {"x": 10, "y": True, "z": "abc"}

# print(my_dict["x"])
# print(my_dict["y"])
# print(my_dict["z"])
# print(my_dict.get("a"))

# my_list = [True, 10, "abc", None, {}]

# for elem in my_list:
#     print(elem)
#     print(type(elem))
#     print()

# video_info = ("1920x1080", True, 3)

# for elem in video_info:
#     print(elem)
#     print(type(elem))
#     print()

# my_dict = {
#     "x": 10,
#     "y": True,
#     "z": "abc",
#     "a": 234,
# }

# for elem in my_dict:
#     print(elem)
#     print(type(elem))
#     print()

# for key in my_dict:
#     print(key, my_dict[key])
#     print(type(key))
#     print()

# for elem in my_dict:
#     print(my_dict[elem])
#     print(type(elem))
#     print()

# print(elem)
# print(dir())

# my_dict = {
#     "x": 10,
#     "y": True,
#     "z": "abc",
#     "a": 234,
# }

# for item in my_dict.items():
#     key, value = item
#     print(f"{key} + {value}")
#     print(key, value)
#     print()

# for key in my_dict.items():
#     print(type(key))
#     print(key)
#     # print(my_dict[key])
#     print()

# for item in my_dict.items():
#     print(item)
#     key, value = item
#     print(key, value)
#     print()

# print(type(my_dict.items()))

# for k, v in my_dict.items():
#     print(k, v)
#     print(type(v))
#     print()

# age_nums = {37, 37, 41}

# for id in age_nums:
#     print(id)

# my_name = "Dmitry"

# for i in my_name:
#     print(i)

# for num in range(5, 45, 6):
#     print(num)


# def filter_list(list_to_filter, value_type):
#     def check_element_type(elem):
#         return isinstance(elem, value_type)

#     return filter(check_element_type, list_to_filter)


# result = filter_list([35, None, "abc", 10, 67.9, False, True, 78], int)
# print(result)  # <filter object at 0x1036f5c00>
# print(list(result))  # [35, 10, False, True, 78]

# print(isinstance(True, bool))
# print(isinstance(True, int))
# print(isinstance(True, object))
# print(int.__subclasses__())


# def filter_list(list_to_filter, value_type):
#     def check_element_type(elem):
#         print(type(elem))
#         return type(elem) is value_type

#     return list(filter(check_element_type, list_to_filter))


# result = filter_list([35, None, "abc", 10, 67.9, False, True, 78], int)
# print(result)  # [35, 10, 78]


# def filter_list(list_to_filter, value_type):  # запись через lambda-функцию
#     return list(filter(lambda elem: type(elem) is value_type, list_to_filter))


# result = filter_list([35, None, "abc", 10, 67.9, False, True, 78], int)
# print(result)  # [35, 10, 78]


# Код с тридцать седьмого урока: цикл while
# i = 10

# while i < 50:
#     print(i)
#     i += 10

# while True:
#     answer = input("Enter yes or no: ")
#     if answer == "no":
#         break

# import random

# random_num = random.randint(1, 5)
# while True:
#     num = int(input("Guess the number from 1 to 5: "))
#     if num != random_num:
#         print(f"Of, no, мое число было равно {random_num}. Try again...")
#         continue
#     print("Congratulations!", random_num)
#     break


# Код с тридцать восьмого урока: сокращенный цикл for in
# all_nums = [-8, -18, -9, 0, 67, 5, -5]

# absolute_nums = []
# positive_nums = []
# for num in all_nums:
#     absolute_nums.append(abs(num))

# print("Первоначально дано: ", all_nums)
# print()
# print("Абсолютные значения: ", absolute_nums)
# print()

# absolute_nums_list_comp = [abs(num) for num in all_nums]
# print(absolute_nums_list_comp)

# for num in all_nums:
#     if num >= 0:
#         positive_nums.append(num)

# print(all_nums)
# print()
# print(positive_nums)

# positive_nums_list_comp = [num for num in all_nums if num >= 0]
# print(positive_nums_list_comp)

# my_set = {1, 9, 27}
# new_my_set = set()

# for elem in my_set:
#     new_my_set.add(elem * elem)

# print(my_set)
# print(new_my_set)

# new_my_set_comp = {elem * elem for elem in my_set}
# print(new_my_set_comp)

# my_name = {
#     "D": 1,
#     "I": 2,
#     "M": 3,
#     "A": 4,
# }

# new_my_name = {}

# for k, v in my_name.items():
#     new_my_name[k] = v * 9

# print(my_name)
# print()
# print(new_my_name)

# new_my_name_comp = {k: v * 9 for k, v in my_name.items()}
# new_my_name_comp = {v * 9 for k, v in my_name.items()} # из словаря получили набор
# new_my_name_comp = [v * 9 for k, v in my_name.items()]  # из словаря получили список™

# print(new_my_name_comp)
# print(type(new_my_name_comp))

# my_ages = [37, 37, 41]

# my_ages_comp_dict = {
#     k: v + 100 for k, v in enumerate(my_ages)
# }  # преобразование списка в словарь
# print(my_ages_comp_dict)

# nums = (3, 5, 10)

# squares = (num * num for num in nums)

# print(squares)

# print(type(squares))

# squares = (num * num for num in range(8)) # создали генератор
# print(squares)
# print(type(squares))

# for num in squares:
#     print(num)

# nums = [3, 5, 7]
# gen = (num * num for num in nums)  # создали генератор
# # squares = list(gen)  # конвертация генератора в список
# # print(squares)
# # print(type(squares))

# squares_tuple = tuple(gen)  # конвертация генератора в кортеж
# print(squares_tuple)
# print(type(squares_tuple))

# from sys import getsizeof

# squares_gen = (num * num for num in range(100_000))
# print(getsizeof(squares_gen))
# print(type(squares_gen))
# # print(squares_gen[6]) # TypeError: 'generator' object is not subscriptable
# for elem in squares_gen:
#     print(elem)
#     if elem == 9:
#         break

# squares_list = [num * num for num in range(100_000)]
# print(getsizeof(squares_list))
# print(type(squares_list))


# Код с тридцать девятого урока: объекты и классы
# class God:
#     def programming(self):
#         print("My first programm: 'Hello world!'")


# i_dimas = God()
# i_dmitry = dict()

# print(i_dimas)
# print(type(i_dimas))
# print(isinstance(i_dimas, God))
# print(isinstance(i_dimas, object))

# i_dimas.programming()

# # print(dir(i_dimas))
# print(i_dimas.__dict__)  # {}
# i_dimas.programming()

# i_dima = God()
# print(i_dimas == i_dima)  # False
# print(id(i_dimas), id(i_dima))

# # i_dimas.programming(i_dimas) # TypeError: God.programming() takes 1 positional argument but 2 were given
# God.programming(i_dimas) # My first programm: 'Hello world!'


# class Comment:
#     # def __init__(self, text):
#     #     self.text = text
#     #     self.votes_qty = 0

#     def __init__(self, text, initual_votes_qty=9):
#         self.text = text
#         self.votes_qty = initual_votes_qty

#     # def upvote(self):
#     #     self.votes_qty += 1

#     def upvote(self, qty):
#         self.votes_qty += qty

#     def reset_votes_qty(self):
#         self.votes_qty = 0


# first_comment = Comment("Первый комментарий", 7)
# # print(first_comment)
# # print(type(first_comment))
# # print()
# # print(first_comment.text)
# # print(first_comment.votes_qty)
# # print()
# # print(first_comment.__dict__)
# # print()
# # print(dir(first_comment))

# # first_comment.upvote()
# # print(first_comment.votes_qty)

# # first_comment.upvote(9)
# # print(first_comment.votes_qty)

# # first_comment.upvote(20)
# # print(first_comment.votes_qty)

# # first_comment.upvote = 10
# # # first_comment.upvote() # получили ошибку
# # print(first_comment.__dict__)

# # second_comment = Comment("Второй комментарий")
# # second_comment.upvote(3)
# # print(second_comment.votes_qty)

# print(first_comment.votes_qty)
# first_comment.reset_votes_qty()
# print(first_comment.votes_qty)


# class Comment:
#     total_comments = 0  # атрибут класса

#     def __init__(self, text, initual_votes_qty=9):  # атрибут экземпляра
#         self.text = text
#         self.votes_qty = initual_votes_qty
#         Comment.total_comments += 1

#     def upvote(self, qty):
#         self.votes_qty += qty

#     def reset_votes_qty(self):
#         self.votes_qty = 0

#     @staticmethod  # декоратор
#     def merge_comments(first, second):
#         return f"{first} {second}"

#     @staticmethod
#     def new_comments(text, new):
#         return f"Комментарий {text} добавлен {new}"


# # first_comment = Comment("Первый комментарий", 7)
# # print(first_comment.text)  # метод привязанный, если первый параметр self
# # print(first_comment.votes_qty)

# # print(first_comment.upvote)
# # print(Comment.upvote)

# # # Comment.upvote()  # TypeError: Comment.upvote() missing 2 required positional arguments: 'self' and 'qty'
# # first_comment.upvote(3)
# # print(first_comment.votes_qty)
# # Comment.upvote(first_comment, 5)
# # print(first_comment.votes_qty)
# # print(Comment)
# # print(object)

# # print(isinstance(first_comment, Comment))
# # print(type(first_comment) == Comment)

# # print(isinstance(first_comment, object))
# # print(type(first_comment) == object)  # False
# # print(type(Comment) == object)
# # print(type(Comment))

# # m_1 = Comment.merge_comments("Hello", "world")
# # print(m_1)
# # m_2 = first_comment.merge_comments("Hello", "Python")
# # print(m_2)

# # m_3 = Comment.new_comments("Новый комментарий", "Dima")
# # print(m_3)

# # m_4 = first_comment.new_comments(first_comment.text, "Dima")
# # print(m_4)

# new_first_comment = Comment("Первый комментарий")
# print(Comment.total_comments)

# new_second_comment = Comment("Второй комментарий")
# print(Comment.total_comments)

# # print(new_first_comment.total_comments)

# # new_first_comment.total_comments = 9
# # print(new_first_comment.total_comments)  # изменился - 9
# # print(
# #     new_first_comment.__dict__
# # )  # {'text': 'Первый комментарий', 'votes_qty': 9, 'total_comments': 9}
# # print(Comment.total_comments)  # не изменился - 2
# # print(Comment.__dict__)  # 'total_comments': 2

# print(new_first_comment.total_comments)  # 2

# Comment.total_comments = 56
# print(Comment.total_comments)  # 56
# print(new_first_comment.total_comments)  # 56


# Код с сорокового урока: магические методы в классах
# class Comment:
#     def __init__(self, text):
#         self.text = text
#         self.votes_qty = 0

#     def upvote(self):
#         self.votes_qty += 1

#     # def __add__(self, other):
#     #     return {
#     #         f"{self.text} {other.text}": self.votes_qty + other.votes_qty
#     #     }  # возвращаю словарь

#     def __add__(self, other):
#         return {
#             "text": f"{self.text} {other.text}",
#             "total_votes_qty": self.votes_qty + other.votes_qty,
#         }  # возвращаю словарь

#     def __compare__(self, other):
#         if self.text == other.text and self.votes_qty == other.votes_qty:
#             return True
#         else:
#             return False


# first_comment = Comment("My first comment")
# first_comment.upvote()
# second_comment = Comment("Next comment")
# second_comment.upvote()
# second_comment.upvote()
# # print(first_comment + second_comment) # не работает из "коробки": TypeError: unsupported operand type(s) for +: 'Comment' and 'Comment'
# # first_comment.__add__(second_comment) # AttributeError: 'Comment' object has no attribute '__add__'. Did you mean: '__hash__'?

# print(first_comment + second_comment)  #  работает из "коробки": добавили def __add__
# print(first_comment.__compare__(second_comment))

# third_comment = Comment("Next comment")
# third_comment.upvote()
# third_comment.upvote()
# print(first_comment.__compare__(third_comment))
# print(second_comment.__compare__(third_comment))
# print(third_comment.__compare__(third_comment))

# print(first_comment.votes_qty, second_comment.votes_qty, third_comment.votes_qty)


# class ExtendedList(list):
#     def print_list_info(self):
#         print(f"List has {len(self)} elements")


# custom_list = ExtendedList([5, 7, 0, 6])
# custom_list.print_list_info()
# print(custom_list[2])

# custom_list.append(9)
# print(custom_list)
# custom_list.print_list_info()

# # print(custom_list.__dict__)  # {}
# # print(ExtendedList.__dict__)
# # print(list.__dict__)
# # print()
# # print(object.__dict__)
# # print(object.__subclasses__())
# # print(list.__subclasses__())
# # print(ExtendedList.__subclasses__())


# class MyExList(ExtendedList):
#     def print_list_info(self):
#         print(f"List has {len(self)} elements")


# print(ExtendedList.__subclasses__())


# Код с сорок первого урока: модули
# import main_module_1 as mm1

# print(
#     mm1
# )  # <module 'main_module_1' from '/Users/dmitrijgerasimcuk/Downloads/3. Полныи Курс по Python/0. Code/Python/lessons/main_module_1.py'>
# print(type(mm1))  # <class 'module'>

# print(dir(mm1))

# print(mm1.my_name)  # Dmitry

# mm1.print_sum(7, 13)  # 20

# from main_module_1 import my_name as name, print_sum as p_s

# print(name)  # Dmitry
# p_s(0, 9)  # 9

# from main_module_1 import *

# print(my_name) #Dmitry

# print(
#     dir()
# )  # ['__annotations__', '__builtins__', '__cached__', '__doc__', '__file__', '__loader__', '__name__', '__package__', '__spec__']
# print(__name__)  # __main__
# print(type(__name__))  # <class 'str'>
# print(__name__ == "__main__") # True

# from main_module_1 import *

# print("main.py: ", __name__)
# print("main.py: ", __name__ == "__main__")

# import os

# help(os)
# help("calendar")
# help("os")

# from main_module_1 import my_name

# help(my_name) #main_module_1.py:  main_module_1
# # main_module_1.py:  False
# # No Python documentation found for 'Dmitry'.
# # Use help() to get the interactive help utility.
# # Use help(str) for help on the str class.

# help("modules")

# from math import pi
# print(pi)

# import math
# print(math.pow(4, 0)) # 1.0

# import math

# print(type(math))  # <class 'module'>
# print(dir(math)) # ['__doc__', '__file__', '__loader__', '__name__', '__package__', '__spec__', 'acos', 'acosh', 'asin', 'asinh', 'atan', 'atan2', 'atanh', 'cbrt', 'ceil', 'comb', 'copysign', 'cos', 'cosh', 'degrees', 'dist', 'e', 'erf', 'erfc', 'exp', 'exp2', 'expm1', 'fabs', 'factorial', 'floor', 'fmod', 'frexp', 'fsum', 'gamma', 'gcd', 'hypot', 'inf', 'isclose', 'isfinite', 'isinf', 'isnan', 'isqrt', 'lcm', 'ldexp', 'lgamma', 'log', 'log10', 'log1p', 'log2', 'modf', 'nan', 'nextafter', 'perm', 'pi', 'pow', 'prod', 'radians', 'remainder', 'sin', 'sinh', 'sqrt', 'tan', 'tanh', 'tau', 'trunc', 'ulp']

# import pack.main_module_2 as pmm2

# pmm2.my_name("Dimas")
# print(pmm2.c)

# pmm2.c = False
# print(pmm2.c)

# print(pmm2.c)

# from pack.main_module_1 import my_name

# print(my_name)


# Код с сорок второго урока: json
# import json as js

# json_str = '{"id": 235, "brand": "Nike", "qty": 84, "status": {"isForSale": true}}'

# str_result = js.loads(json_str)
# print(type(str_result))  # <class 'dict'>

# print(str_result["brand"])
# print(str_result["id"])
# print(str_result["status"]["isForSale"])

# my_dict = {
#     "id": 235,
#     "brand": "Nike",
#     "qty": 84,
#     "status": {"isForSale": True},
# }

# str_json = js.dumps(my_dict)
# print(
#     str_json
# )  # {"id": 235, "brand": "Nike", "qty": 84, "status": {"isForSale": true}}
# print(type(str_json))  # <class 'str'>

# str_json_formating = js.dumps(my_dict, indent=3)
# print(
#     str_json
# )  # {"id": 235, "brand": "Nike", "qty": 84, "status": {"isForSale": true}}
# print(type(str_json))  # <class 'str'>

# json_array = "[1, 2, 3]"
# json_python_formating = js.loads(json_array)
# print(json_python_formating)  # [1, 2, 3]
# print(type(json_python_formating))  # <class 'list'>

# json_from_list = js.dumps(json_python_formating)
# print(type(json_from_list)) # <class 'str'>
# print(json_from_list)


# Код с сорок третьего урока: работа с файлами
# from os import path  # функциональный подход
# from pathlib import Path  # объектно-ориентированный подход

# print(
#     path.abspath(".")
# )  # /Users/dmitrijgerasimcuk/Downloads/3. Полныи Курс по Python/0. Code
# print(type(path))  # <class 'module'>

# print(
#     Path(".").absolute()
# )  # /Users/dmitrijgerasimcuk/Downloads/3. Полныи Курс по Python/0. Code
# print(type(Path))  # <class 'type'>

# # first = path.abspath(".")
# # second = Path(".").absolute()

# # print(first == second)  # False
# # print()
# # file_path = Path("text.txt")

# # print([m for m in dir(file_path) if not m.startswith("_")]) # вывели все атрибуты без магических методов (фильтр "_")

# print(Path.cwd())  # /Users/dmitrijgerasimcuk/Downloads/3. Полныи Курс по Python/0. Code
# print(
#     Path("Users") / "dmitrujgerasimchuk" / "Desktop" / "Документы" / "1. Личное"
# )  # формирование путей: Users/dmitrujgerasimchuk/Desktop/Документы/1. Личное

# print(Path("/Users/dmitrujgerasimchuk/Desktop/Документы/1. Личное").exists())  # False
# print(Path("main.py").exists()) # False
# from pathlib import Path

# print(Path("main.py").exists())  # проверка наличия директории или файла
# print(Path(".").absolute())
# print(
#     Path(
#         "/Users/dmitrijgerasimcuk/Downloads/3. Полныи Курс по Python/0. Code"
#     ).exists()  # True
# )
# print(Path("main.py").exists())  # False

# print(
#     Path(
#         "/Users/dmitrijgerasimcuk/Downloads/3. Полныи Курс по Python/0. Code / Python / lessons / main.py "
#     ).is_file()
# )  # False (?)

# print(
#     Path(
#         "/Users/dmitrijgerasimcuk/Downloads/3. Полныи Курс по Python/0. Code / Python / lessons "
#     ).is_dir()
# )  # False (?)

# from pathlib import Path

# for f in Path(".").iterdir():
#     print(f) #Information, .DS_Store, Python, .git

# from os import path

# print(path.curdir)  # . - относительный путь
# print(path.abspath(".")) # /Users/dmitrijgerasimcuk/Downloads/3. Полныи Курс по Python/0. Code/Python

# from pathlib import Path

# # print(type(Path))  # <class 'type'>
# cwd = Path()
# # print(cwd)  # .
# # print(isinstance(cwd, Path))  # True
# # print(type(cwd))  # <class 'pathlib.PosixPath'>
# # print(Path.__subclasses__()) # [<class 'pathlib.PosixPath'>, <class 'pathlib.WindowsPath'>]
# # print(dir(cwd))
# # print(cwd.absolute()) # /Users/dmitrijgerasimcuk/Downloads/3. Полныи Курс по Python/0. Code/Python
# cwd = (
#     Path("/Users")
#     .joinpath("dmitrijgerasimcuk")
#     .joinpath("Downloads")
#     .joinpath("3. Полныи Курс по Python")
#     .joinpath("0. Code")
#     .joinpath("Python")
#     .joinpath("lessons")
# )
# print(
#     cwd
# )  # /Users/dmitrijgerasimcuk/Downloads/3. Полныи Курс по Python/0. Code/Python/lessons

# cwd = (
#     Path("/Users")
#     / "dmitrijgerasimcuk"
#     / "Downloads"
#     / "3. Полныи Курс по Python"
#     / "0. Code"
#     / "Python"
#     / "lessons"
# )
# print(
#     cwd
# )  # /Users/dmitrijgerasimcuk/Downloads/3. Полныи Курс по Python/0. Code/Python/lessons

# print(cwd.exists())  # True - папка есть
# print(cwd.is_dir())  # True - это папка/директория

# cwd = (
#     Path("/Users")
#     / "dmitrijgerasimcuk"
#     / "Downloads"
#     / "3. Полныи Курс по Python"
#     / "0. Code"
#     / "Python"
#     / "lessons"
#     / "new_dir"
# )
# # print(cwd.mkdir()) # None (папка создалась)
# if not cwd.exists():
#     cwd.mkdir()

# if cwd.exists():
#     cwd.rmdir()  # удаление папки

# from pathlib import Path

# # test_file = open("test.txt", "w")
# # print(test_file)  # <_io.TextIOWrapper name='test.txt' mode='w' encoding='utf-8'>
# # print(type(test_file))  # <class '_io.TextIOWrapper'>
# # test_file.write("First string\n")
# # test_file.write("Second string\n")
# # # print(test_file.read())  # io.UnsupportedOperation: not readable
# # test_file.close()  # если не закрыть, то нельзя прочитать ("w")

# # test_file = open("test.txt")  # открываем файл
# # print(test_file.read())

# # или более короткая запись:
# with open("test.txt", "w") as test_file:
#     test_file.write("First string\n")
#     test_file.write("Second string\n")

# # test_file = open("test.txt")
# # print(test_file.read())
# # test_file.close() # закрывать всегда (!)

# # или более короткая запись:
# with open("test.txt") as test_file:
#     print(test_file.read())

# with open("test.txt", "a") as test_file:
#     test_file.write("First string\n")
#     test_file.write("Second string\n")

# with open("test.txt") as test_file:
#     print(test_file.read())

# with open("test.txt", "w") as test_file:
#     test_file.write("First string\n")
#     test_file.write("Second string\n")
#     test_file.write("\n")
#     test_file.write("Third string\n")

# # with open("test.txt") as test_file:
# #     # lines = test_file.readlines()
# #     # for line in lines:
# #     #     print(line)
# #     ## аналогично но более кратко:
# #     for line in test_file:
# #         print(line)
# with open("test.txt") as test_file:
#     # print(test_file.readline())  # First string
#     # print(test_file.readline())  # Second string
#     # print(test_file.readline())  # Third string
#     # res = test_file.readline()
#     # print(res)
#     # print(type(res)) # <class 'str'>
#     # print(res == "") # True
#     # или более короткая заапись:
#     while True:
#         line = test_file.readline()
#         if not line:
#             break
#         print(line, "yes!")

# my_file = Path("test.txt")

# if my_file.exists():
#     my_file.unlink()  # удаление файла


# Код с сорок четвертого урока: работа с zip-архивами
# from zipfile import ZipFile
# from pathlib import Path

# # # Path("./my-files").mkdir()
# # Path("my-file").mkdir()

# # with open("my-file/first.txt", "w") as f_t_1:
# #     f_t_1.write("This is first file")

# # with open("my-file/second.txt", "w") as f_t_2:
# #     f_t_2.write("This is second file")

# """Cоздание архива"""
# # with ZipFile("my-files.zip", mode="w") as my_zip_file:
# #     print(my_zip_file)
# #     for elem in Path("my-file").iterdir():
# #         print(elem)
# #         my_zip_file.write(elem)
# """Распаковка архива"""
# with ZipFile("my-files.zip", mode="r") as m_z_f:
#     # m_z_f.extractall("my-files-unzipped")
#     # info = m_z_f.infolist() # информация о файлах в архиве
#     # print(info)
#     f_n = m_z_f.filename  # название архива
#     print(f_n)


# # Код с сорок пятый урока: работа с csv файлами
# import csv

# with open("test.csv", "w") as csv_file:
#     writer = csv.writer(csv_file, delimiter=";")
#     writer.writerow(["user_id", "user_name", "user_age"])
#     writer.writerow([1, "Dmitry", 37])
#     writer.writerow([2, "Irina", 37])
#     writer.writerow([3, "Slava", 41])

# with open("test.csv", "r") as t_csv:
#     reader = csv.reader(t_csv, delimiter=";")
#     # print(reader)
#     # print(type(reader))
#     # for line in reader:
#     #     print(line)
#     # csv_list = list(reader)
#     # print(csv_list)
#     for line in reader:
#         print(line)
#     # for line in reader:
#     #     print(line)
#     print(reader.line_num)


# Код с сорок шестого урока: работа датами и временем
# from datetime import date

# # print(date)
# # print(type(date))

# today = date(2024, 8, 26)
# # print(today)

# # print(today.day)
# # print(today.month)
# # print(today.year)

# print(today.isocalendar()) # datetime.IsoCalendarDate(year=2024, week=35, weekday=1)

# from datetime import time

# my_time = time(15, 10, 45, 5)
# print(my_time)

# print(my_time.hour)
# print(my_time.minute)
# print(my_time.second)
# print(my_time.microsecond)

# from datetime import datetime

# my_datetime = datetime(2024, 6, 20, 20, 4, 5, 9)
# print(my_datetime)

# print(my_datetime.day)
# print(my_datetime.hour)
# print(my_datetime.microsecond)

# print(my_datetime.isoformat())  # 2024-06-20T20:04:05.000009

# print(my_datetime.now().hour)  # 15 (now - 15:21)
# print(my_datetime.now().minute) # 21

# from datetime import datetime

# my_datetime = datetime(2024, 6, 20, 20, 4, 5, 9)

# print(my_datetime.strftime("%d-%b-%Y"))  # 20-Jun-2024
# print(my_datetime.strftime("%d-%m-%Y"))  # 20-06-2024
# print(my_datetime.strftime("%d/%m/%Y"))  # 20/06/2024
# print(my_datetime.strftime("%d-%b-%Y %H:%M:%S"))  # 20-Jun-2024 20:04:05

# date_str = "20/06/2024"
# converteed_date = datetime.strptime(date_str, "%d/%m/%Y")
# print(converteed_date)  # 2024-06-20 00:00:00

# date_str_2 = "20/06/2024/14/9"
# converteed_date_2 = datetime.strptime(date_str_2, "%d/%m/%Y/%H/%M")
# print(converteed_date_2) # 2024-06-20 14:09:00

# from datetime import datetime, timedelta

# my_datetime = datetime(2024, 6, 20, 20, 4, 5, 9)
# print(timedelta)

# print(my_datetime + timedelta(days=100))  # 2024-09-28 20:04:05.000009
# print(my_datetime + timedelta(days=100, minutes=146_88))  # 2024-10-09 00:52:05.000009
# print(my_datetime - timedelta(weeks=78, days=9, minutes=57)) #2022-12-13 19:07:05.000009

# import time

# # print(time)

# # unix_era = time.time()
# # print(unix_era)  # 1724683874.287841 sec
# # unix_era_sec = time.ctime(1724683874)
# # print(unix_era_sec)  # Mon Aug 26 17:51:14 2024

# # time.sleep(2.5)
# # print(unix_era) # 1724684099.884686 (замедление на 2,5 секунды)

# # start_time = time.time()
# # time.sleep(3)
# # end_time = time.time()
# # print(end_time - start_time) # 3.0050411224365234

# start_time = time.time()

# # my_range = range(100_000)
# my_range = list(range(1_000_000_00))

# print(my_range[1000])

# end_time = time.time()

# # print("Total duration of the operation", end_time - start_time) # Total duration of the operation 2.1219253540039062e-05
# print("Total duration of the operation", end_time - start_time) # Total duration of the operation 1.267575740814209


# Код с сорок седьмого урока: модули для работы с числами
# import random

# print(random.random())  # 0.6139612400810384
# print(random.randint(7, 90))  # 68
# print(random.choice("0123456789"))  # 6
# print(random.choice("Dima"))  # a
# print(random.choice([30, 37, 41]))  # 30
# print(random.choices([1, 2, 3, 4, 5, 6, 7, 8, 9], k=3))  # [5, 5, 2]
# # print(random.shuffle([1, 2, 3, 4, 5, 6, 7, 8, 9])) # None
# my_list = [1, 2, 3, 4, 5, 6, 7, 8, 9]
# random.shuffle(my_list)
# print(my_list)  # [6, 9, 7, 2, 5, 1, 4, 3, 8]

# print(
#     random.choices("0123456789", k=9)
# )  # ['1', '3', '8', '8', '6', '3', '0', '2', '0']
# print("".join(random.choices("0123456789", k=10)))  # passport - 2452685208
# print("".join(random.choices("ABCDEF0123456789", k=10)))  # passport - 5CAD56A5CD

# import secrets
# import string

# # print(string.ascii_letters)
# # print(string.ascii_lowercase)
# # print(string.ascii_uppercase)
# # print(string.digits)
# # print(string.punctuation)
# # print(string.ascii_letters + string.digits + string.punctuation)

# all_chars = string.ascii_letters + string.digits + string.punctuation

# print(secrets.choice(all_chars))  # i
# print(
#     secrets.choice(all_chars) for elem in range(10)
# )  # <generator object <genexpr> at 0x101639d20>
# print("".join(secrets.choice(all_chars) for elem in range(10)))  # password - omW';u3wR{

# print("".join(secrets.choice(all_chars) for i in range(37))) # password (37) - ~Zg3o?=6MpYk@G,(wm0+Hv4[&WNN[hc#rd{!g

# import math

# print(math.pi)  # 3.141592653589793
# print(math.e)  # 2.718281828459045

# print(math.sqrt(36))  # 6.0

# print(math.log(100))  # 4.605170185988092

# print(math.factorial(21))  # 51090942171709440000

# print(dir(math))

# import math

# def calc_factorial(num):
#     if type(num) is not int:
#         raise TypeError("Number must be integer")
#     if num <= 0:
#         raise ValueError("Number must be positive")
#     if num == 1:
#         return 1
#     return calc_factorial(num - 1) * num # рекурсия

# # calc_factorial("abc")
# # calc_factorial(0)
# factorial = calc_factorial(10)
# print(factorial)

# factorial_math = math.factorial(10)
# print(factorial_math)


# Код с сорок восьмого урока: работа с регулярными выражениями
# import re

# my_string = "My name is Dmitry"

# res = re.search("Dmitry", my_string)
# print(res) # <re.Match object; span=(11, 17), match='Dmitry'>
# print(type(res)) # <class 're.Match'>

# res = re.search("D....y", my_string)
# print(res)  # <re.Match object; span=(11, 17), match='Dmitry'>
# print(type(res))  # <class 're.Match'>

# res = re.search("D....y$", my_string)
# print(res) # <re.Match object; span=(11, 17), match='Dmitry'>

# res = re.search("^M.*s", my_string)
# print(res) # <re.Match object; span=(0, 10), match='My name is'>

# my_string_2 = "My name is Dmitry."
# res = re.search("D.*y\.$", my_string_2)
# print(res)  # <re.Match object; span=(11, 18), match='Dmitry.'>

# print("D.*y\n.$")  # D.*y (+ на новой строке) .$
# print(r"D.*y\n.$")  # D.*y\n.$

# print(res.span())  # (11, 18)
# print(res.start()) # 11
# print(res.end()) # 18

# import re

# my_string = "My name is Dmitry."
# my_string_2 = "My name is Dmitry. Dmitry is a srudent."
# # other_string = "My name is Dmitry!"
# # res = re.search(r"D.*y\.$", my_string)
# # print(res)  # <re.Match object; span=(11, 18), match='Dmitry.'>

# # my_pattern = re.compile(r"D.*y\.$")
# # print(my_pattern)  # re.compile('D.*y\\.$')

# my_pattern = re.compile(r"^My.*\.$")
# my_pattern_2 = re.compile("D....y")
# print(my_pattern)  # re.compile('^My.*\\.$')
# # print(my_pattern.search(my_string)) # <re.Match object; span=(11, 18), match='Dmitry.'>
# print(
#     my_pattern.match(my_string)
# )  # <re.Match object; span=(0, 18), match='My name is Dmitry.'>
# # print(my_pattern.match(other_string)) # None - строка заканчивается на "!", а паттерн заканчивается "."
# # print(my_pattern.match(my_string_2)) # <re.Match object; span=(0, 39), match='My name is Dmitry. Dmitry is a srudent.'>
# print(my_pattern_2.findall(my_string_2))  # ['Dmitry', 'Dmitry']

# """Проверка электронной почты на правильность написания"""
# import re

# # 1 вариант:
# email_regexp = r"[a-zA-Z0-9_.]+@[a-zA-Z0-9]+\.[a-zA-Z0-9-.]+$"
# email_check_pattern = re.compile(email_regexp)


# # 2 вариант:
# def check_regexp(email):
#     email_regexp = r"[a-zA-Z0-9_.]+@[a-zA-Z0-9]+\.[a-zA-Z0-9-.]+$"
#     email_check_pattern = re.compile(email_regexp)
#     validation_result = "valid" if email_check_pattern.fullmatch(email) else "not valid"
#     return (email, validation_result)  # возвращаем кортеж


# print(
#     email_check_pattern.fullmatch("arhdigger@gmail.com")
# )  # прошел проверку email: <re.Match object; span=(0, 19), match='arhdigger@gmail.com'>
# print(
#     email_check_pattern.fullmatch("arhdiggergmail.com")
# )  # не прошел проверку email: None
# print(
#     email_check_pattern.fullmatch("arhdigger@gmailcom")
# )  # не прошел проверку email: None
# print(email_check_pattern.fullmatch("@gmail.com"))  # не прошел проверку email: None
# print(email_check_pattern.fullmatch("arhdigger@"))  # не прошел проверку email: None
# print()
# print(check_regexp("arhdigger@gmail.com")) # ('arhdigger@gmail.com', 'valid')
# print(check_regexp("arhdiggergmail.com")) # ('arhdiggergmail.com', 'not valid')
# print(check_regexp("arhdigger@gmailcom")) # ('arhdigger@gmailcom', 'not valid')
# print(check_regexp("@gmail.com")) # ('@gmail.com', 'not valid')
# print(check_regexp("arhdigger@")) # ('arhdigger@', 'not valid')


# Код с сорок девятого урока: отправка email
# """Код не запускается, так как smtp-сервер не установлен"""

# from email.message import EmailMessage
# import smtplib
# from string import Template
# from pathlib import Path

# my_email = EmailMessage()

# html_template = Template(
#     Path(
#         "/Users/dmitrijgerasimcuk/Downloads/3. Полныи Курс по Python/0. Code/Python/lessons/templates/index.html"
#     ).read_text()
# )  # создание шаблона
# html_content = html_template.substitute(
#     {"name": "Dmitry", "date": "tomorrow"}
# )  # замена имен в шаблоне

# my_email["from"] = "Dmitry <arhdigger@ya.ru>"
# my_email["to"] = "arhdigger@gmail.com"
# my_email["subject"] = "Проверка"
# # my_email.set_content("Привет! Проверка прошла?")
# my_email.set_content(html_content, "html")

# with open(
#     "/Users/dmitrijgerasimcuk/Downloads/3. Полныи Курс по Python/0. Code/Python/lessons/images/iPad 2021 Landscape.png",
#     "rb",
# ) as img:
#     image_data = img.read()
#     my_email.add_attachment(
#         image_data, maintype="image", subtype="png", filename="iPad 2021 Landscape.png"
#     )  # добавляем картинку к письму

# with smtplib.SMTP(host="127.0.0.1", port=2525) as smtp_server:
#     smtp_server.ehlo()
#     # smtp_server.starttls()
#     smtp_server.send_message(my_email)
#     print("Email was sent!")


# Код с пятидесятого урока: работа с базой данных SQLite
# import sqlite3

# DB_NAME = "sqlite_db.db"

# # '''Создание соединения'''
# # with sqlite3.connect(DB_NAME) as sqlite_conn:
# #     print(sqlite_conn) # подключение к БД - <sqlite3.Connection object at 0x101528e50>
# #     print(sqlite3.version) # 2.6.0

# # '''Создание таблицы'''
# # with sqlite3.connect(DB_NAME) as sqlite_conn:
# #     sql_request = """CREATE TABLE IF NOT EXISTS courses (
# #         id integer PRIMARY KEY,
# #         title text NOT NULL,
# #         student_qty integer,
# #         reviews_qrt integer
# #     );"""
# #     sqlite_conn.execute(sql_request)

# # '''Запись данных в таблицу'''
# # with sqlite3.connect(DB_NAME) as sqlite_conn:
# #     sql_request = "INSERT INTO courses VALUES(?, ?, ?, ?)"
# #     sqlite_conn.execute(sql_request, (1, "Python course", 2, 1))
# #     sqlite_conn.commit()  # для сохранения данных в БД

# # '''Запись данных в таблицу нескольких данных'''
# # courses = [(2, "Инвестиции", 1, 1), (3, "English", 2, 2), (4, "SQL", 1, 2)]

# # with sqlite3.connect(DB_NAME) as sqlite_conn:
# #     sql_request = "INSERT INTO courses VALUES(?, ?, ?, ?)"
# #     for course in courses:
# #         sqlite_conn.execute(sql_request, course)
# #     sqlite_conn.commit()  # для сохранения данных в БД

# with sqlite3.connect(DB_NAME) as sqlite_conn:
#     # sql_request = "SELECT * FROM courses" # вывод запроса
#     # sql_cursor = sqlite_conn.execute(sql_request)
#     # # for record in sql_cursor:
#     # #     print(record[1])
#     # #     print(record)
#     # #     print()
#     # # records = sql_cursor.fetchall()
#     # # print(records) # [] так как выше мы прошли по сем записям и курсов в конце
#     # records = sql_cursor.fetchall()
#     # print(records) # список из всех кортежей
#     sql_request = "SELECT * FROM courses WHERE reviews_qrt < 2" # фильтр
#     sql_corsor = sqlite_conn.execute(sql_request)
#     answer = sql_corsor.fetchall()
#     print(answer)


# Код с пятьдесят первого урока: другие встроенные модули
# import array
# print(dir(array)) # ['ArrayType', '__doc__', '__file__', '__loader__', '__name__', '__package__', '__spec__', '_array_reconstructor', 'array', 'typecodes']

# from array import array

# my_int_array = array("i", [4, 10, 4, 5])

# # print(my_int_array)  # array('i', [4, 10, 4, 5])
# # print(type(my_int_array))  # <class 'array.array'>

# # my_int_array.append(15)

# # print(my_int_array)  # array('i', [4, 10, 4, 5, 15])

# # my_int_array.append("abc")  # TypeError: 'str' object cannot be interpreted as an integer

# # print(my_int_array.count(4))  # 2 - количество одинаковых элементов
# # print(my_int_array.count(12))  # 0

# # my_int_array.pop()
# # print(my_int_array)  # array('i', [4, 10, 4])

# # print(len(my_int_array))  # 3

# # for elem in my_int_array:
# #     print(elem)

# # print(my_int_array[1]) # 10

# with open("my_array.bin", "wb") as my_file:
#     my_int_array.tofile(my_file)
#     print("Готово!")

# imported_array = array("i")

# with open("my_array.bin", "rb") as my_file:
#     imported_array.fromfile(my_file, 3)
#     print(imported_array)  # array('i', [4, 10, 4])

# imported_array.reverse()
# print(imported_array) # array('i', [4, 10, 4]) - обратный порядок элементов

# import sys

# print(
#     sys.argv
# )  # ['/Users/dmitrijgerasimcuk/Downloads/3. Полныи Курс по Python/0. Code/Python/lessons/main.py'

# if len(sys.argv) < 3:
#     raise IOError("You must provide username and password")

# # username = sys.argv[1]
# # password = sys.argv[2]

# filename, username, password = sys.argv # ['lessons/main.py', 'Dmitry', '5790654']

# print(username, password)  # Dmitry 5790654

# import webbrowser

# webbrowser.open("https://pypi.org")


# Код с пятьдесят второго урока: виртуальные среды pip и pipenv
# import pygame

# pygame.init()  # pygame 2.6.0 (SDL 2.28.4, Python 3.11.5) Hello from the pygame community. https://www.pygame.org/contribute.html

# import requests

# my_request = requests.get("https://www.python.org")

# print(my_request)
# print(my_request.text)
# print(my_request.status_code)
